# Isles Design & Manufacture

Business website for Isles Design & Manufacture, prepared for https://islesdandm.github.io/.

Contact: islesdandm@gmail.com

Static HTML, CSS and JavaScript. Set GitHub Pages to publish from the main branch, repository root.

The separate caregiver call-button design files are licensed under CERN-OHL-P v2. The linkage calculators retain their proprietary terms in tools/LICENSE.md.
